using UnityEngine;
using VRC.SDKBase;
namespace Pokahina.AnywhereMMD {
 [AddComponentMenu("Pokahina/Anywhere MMD Settings")]
 public sealed class AnywhereMMDOptions:MonoBehaviour,IEditorOnly {
  public bool followAvatarSettings=true;
  public bool keepDancerGrabbing=false;
  [Range(128,3840)]public int captureWidth=2560;
  [Range(2,50)]public float viewingRange=20;
 }
}