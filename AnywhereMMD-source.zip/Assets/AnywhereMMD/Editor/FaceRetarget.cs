using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEditor;
namespace Pokahina.AnywhereMMD.Editor {
 public static class FaceRetarget {
  static uint NameHash(string name){uint crc=0xffffffff;foreach(byte b in Encoding.UTF8.GetBytes(name)){crc^=b;for(int i=0;i<8;i++)crc=(crc>>1)^((crc&1)!=0?0xedb88320u:0u);}return ~crc;}
  public static void Apply(GameObject wearer,GameObject dancer,AnywhereMMD config,Action<UnityEngine.Object> save){
   var timeline=config.performance.GetComponent<Animator>();var original=timeline.runtimeAnimatorController.animationClips.First();
   var clip=UnityEngine.Object.Instantiate(original);clip.name="LoveTrial camera lyrics and original face";
   var body=config.danceController.animationClips.First();var report=new List<string>();int count=0;
   foreach(var binding in AnimationUtility.GetCurveBindings(body).Where(b=>b.propertyName.StartsWith("blendShape."))){
    string src=binding.propertyName.Substring(11);uint hash=0;bool encoded=src.StartsWith("path_0x")&&uint.TryParse(src.Substring(7).Split('_')[0],System.Globalization.NumberStyles.HexNumber,null,out hash);
    bool matched=false;
    foreach(var mesh in dancer.GetComponentsInChildren<SkinnedMeshRenderer>(true)){
     if(!mesh.sharedMesh)continue;
     // Match only the original name or its exact exported CRC. Never substitute expressions.
     for(int i=0;i<mesh.sharedMesh.blendShapeCount;i++){
      string name=mesh.sharedMesh.GetBlendShapeName(i);if(name!=src&&(!encoded||NameHash(name)!=hash))continue;
      string relative=AnimationUtility.CalculateTransformPath(mesh.transform,dancer.transform);
      // Prefer the source path; equivalent face mesh paths may differ after avatar assembly.
      var path=AnimationUtility.CalculateTransformPath(mesh.transform,config.performance);
      AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve(path,typeof(SkinnedMeshRenderer),"blendShape."+name),AnimationUtility.GetEditorCurve(body,binding));
      report.Add(binding.path+" / "+src+" -> "+relative+" / "+name);count++;matched=true;
     }
    }
    if(!matched)report.Add("UNMATCHED: "+binding.path+" / "+src);
   }
   save(clip);var controller=new AnimatorOverrideController(timeline.runtimeAnimatorController);controller.name="LoveTrial original face bindings";controller[original]=clip;save(controller);timeline.runtimeAnimatorController=controller;
   System.IO.File.WriteAllLines(AnywhereMMDPlugin.Work+"face-bindings.txt",new[]{"Matched original expressions: "+count}.Concat(report));
   if(count==0)Debug.LogWarning("Anywhere MMD: no matching original facial shapes found. See face-bindings.txt.",config);
  }
 }
}