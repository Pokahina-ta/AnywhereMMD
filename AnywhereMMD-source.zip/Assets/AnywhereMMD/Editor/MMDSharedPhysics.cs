using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using VRC.Dynamics;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Dynamics.PhysBone.Components;
using VRC.SDK3.Dynamics.Constraint.Components;
using Object=UnityEngine.Object;
namespace Pokahina.AnywhereMMD.Editor {
 public static class MMDSharedPhysics {
  // Shared rig validated against all songs and SDK limits; test flags only support editor diagnostics.
  const bool EnabledByDefault=true;
  public static bool TestEnabled; public static bool TestCompactInteractions; public static Transform LastShared,LastSimulation; public static int RetainedPerSong;
  static string PathOf(Transform t,Transform root)=>AnimationUtility.CalculateTransformPath(t,root);
  static Transform Equivalent(Transform target,Transform from,Transform to){var indices=new Stack<int>();var t=target;while(t!=from){Require(t&&t.parent,"bone outside dancer");indices.Push(t.GetSiblingIndex());t=t.parent;}t=to;while(indices.Count>0){int i=indices.Pop();Require(i<t.childCount,"song skeleton differs");t=t.GetChild(i);}Require(t.name==target.name||target==from,"song bone names differ");return t;}
  static void Require(bool value,string message){if(!value)throw new Exception("MMD shared physics: "+message);}
  static void Curve(AnimationClip clip,string path,Type type,string property,float value)=>AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve(path,type,property),AnimationCurve.Constant(0,.1f,value));
  public static void Apply(GameObject wearer,Dictionary<AnywhereMMD,GameObject> created,Dictionary<string,List<string>> visibility,Action<Object> save,Action<GameObject> registerSimulation=null){
   if(!EnabledByDefault&&!TestEnabled)return;
   var report=new List<string>();
   foreach(var grouping in created.Keys.GroupBy(c=>c.GetComponentInParent<AnywhereMMDOptions>())){
    var options=grouping.Key;if(!options)continue;bool compact=!options.keepDancerGrabbing||TestCompactInteractions;
    var configs=grouping.OrderBy(c=>c.name,StringComparer.Ordinal).ToArray();if(configs.Length<2)continue;
    Require(configs.Length<=16,"at most 16 songs can share one rig");
    var dancers=configs.Select(c=>created[c]).ToArray();var first=dancers[0];
    var sourcePhysics=first.GetComponentsInChildren<VRCPhysBone>(true);if(sourcePhysics.Length==0)continue;
    foreach(var c in configs)Require(Vector3.Distance(c.stage.position,configs[0].stage.position)<.0001f&&Quaternion.Angle(c.stage.rotation,configs[0].stage.rotation)<.001f&&Vector3.Distance(c.stage.lossyScale,configs[0].stage.lossyScale)<.0001f,"song stages differ");
    var shared=new GameObject("Shared Physics");shared.SetActive(false);shared.transform.SetParent(options.transform,false);shared.transform.position=configs[0].stage.position;shared.transform.rotation=configs[0].stage.rotation;shared.transform.localScale=Vector3.Scale(configs[0].stage.lossyScale,new Vector3(1/options.transform.lossyScale.x,1/options.transform.lossyScale.y,1/options.transform.lossyScale.z));
    var simulation=new GameObject("Simulation");simulation.transform.SetParent(shared.transform,false);LastShared=shared.transform;LastSimulation=simulation.transform;
    var map=new Dictionary<Transform,Transform>();
    foreach(var t in first.GetComponentsInChildren<Transform>(true)){
     string path=PathOf(t,first.transform);var target=new GameObject(t==first.transform?"Rig":t.name).transform;target.SetParent(t==first.transform?simulation.transform:map[t.parent],false);target.localPosition=t.localPosition;target.localRotation=t.localRotation;target.localScale=t.localScale;target.gameObject.SetActive(t.gameObject.activeSelf);map.Add(t,target);
    }
    AnywhereMMDPlugin.CopyPhysBones(first,map);
    var rig=map[first.transform];var bones=new HashSet<Transform>{first.transform};var human=first.GetComponent<Animator>();
    for(int i=0;i<(int)HumanBodyBones.LastBone;i++){var bone=human.GetBoneTransform((HumanBodyBones)i);if(bone)bones.Add(bone);}
    foreach(var c in configs)foreach(var binding in c.danceController.animationClips.SelectMany(AnimationUtility.GetCurveBindings).Where(b=>b.type==typeof(Transform))){var t=first.transform.Find(binding.path);if(t)bones.Add(t);}
    // Keep any physics chain that overlaps humanoid animation on its original per-song rig.
    // Constraints never write the transforms that these PhysBones simulate.
    var affected=new Dictionary<VRCPhysBone,HashSet<Transform>>();
    foreach(var pb in sourcePhysics){var set=new HashSet<Transform>();var pending=new Stack<Transform>();pending.Push(pb.rootTransform?pb.rootTransform:pb.transform);while(pending.Count>0){var t=pending.Pop();if(pb.ignoreTransforms.Contains(t))continue;set.Add(t);foreach(Transform child in t)pending.Push(child);}affected.Add(pb,set);}
    var retained=new HashSet<VRCPhysBone>(sourcePhysics.Where(pb=>affected[pb].Overlaps(bones)));var retainedBones=new HashSet<Transform>();
    bool changed;do{changed=false;foreach(var pb in retained)retainedBones.UnionWith(affected[pb]);foreach(var pb in sourcePhysics)if(!retained.Contains(pb)&&affected[pb].Any(t=>retainedBones.Any(r=>t.IsChildOf(r)))){retained.Add(pb);changed=true;}}while(changed);
    RetainedPerSong=retained.Count;
    var retainedIndices=new HashSet<int>(Enumerable.Range(0,sourcePhysics.Length).Where(i=>retained.Contains(sourcePhysics[i])));
    var copiedPhysics=rig.GetComponentsInChildren<VRCPhysBone>(true);Require(copiedPhysics.Length==sourcePhysics.Length,"physics-copy ordering differs");
    for(int i=0;i<sourcePhysics.Length;i++)if(retained.Contains(sourcePhysics[i]))Object.DestroyImmediate(copiedPhysics[i]);
    var constraints=new List<VRCParentConstraint>();
    foreach(var source in bones.OrderBy(t=>PathOf(t,first.transform).Count(ch=>ch=='/'))){var target=map[source];var constraint=target.gameObject.AddComponent<VRCParentConstraint>();constraint.IsActive=false;constraint.GlobalWeight=1;constraint.SolveInLocalSpace=true;constraint.PositionAtRest=target.localPosition;constraint.RotationAtRest=target.localEulerAngles;constraint.Sources.Clear();string path=PathOf(source,first.transform);foreach(var dancer in dancers){var input=Equivalent(source,first.transform,dancer.transform);Require(input,"missing pose input "+path);constraint.Sources.Add(new VRCConstraintSource(input,0,Vector3.zero,Vector3.zero));}constraint.Locked=true;constraint.IsActive=true;constraints.Add(constraint);}
    foreach(var dancer in dancers){
     foreach(var renderer in dancer.GetComponentsInChildren<SkinnedMeshRenderer>(true)){
      renderer.bones=renderer.bones.Select(b=>!b?null:retainedBones.Contains(Equivalent(b,dancer.transform,first.transform))?b:map[Equivalent(b,dancer.transform,first.transform)]).ToArray();if(renderer.rootBone)renderer.rootBone=map[Equivalent(renderer.rootBone,dancer.transform,first.transform)];
     }
     foreach(var renderer in dancer.GetComponentsInChildren<MeshRenderer>(true)){
      var target=renderer.transform;if(retainedBones.Contains(Equivalent(target,dancer.transform,first.transform)))continue;var follow=target.gameObject.AddComponent<VRCParentConstraint>();follow.GlobalWeight=1;follow.SolveInLocalSpace=false;follow.Sources.Add(new VRCConstraintSource(map[Equivalent(target,dancer.transform,first.transform)],1,Vector3.zero,Vector3.zero));follow.Locked=true;follow.IsActive=true;
     }
     var dancerPB=dancer.GetComponentsInChildren<VRCPhysBone>(true);Require(dancerPB.Length==sourcePhysics.Length,"song physics differs");var keep=new List<VRCPhysBone>();for(int i=0;i<dancerPB.Length;i++){if(retainedIndices.Contains(i))keep.Add(dancerPB[i]);else Object.DestroyImmediate(dancerPB[i]);}
     var usedColliders=new HashSet<VRCPhysBoneColliderBase>(keep.SelectMany(pb=>pb.colliders));foreach(var collider in dancer.GetComponentsInChildren<VRCPhysBoneCollider>(true))if(!usedColliders.Contains(collider))Object.DestroyImmediate(collider);
    }
    if(options.followAvatarSettings)foreach(var pair in map){string source=PathOf(pair.Key,first.transform);if(source.Length==0)continue;if(!visibility.TryGetValue(source,out var targets)){targets=new List<string>();visibility.Add(source,targets);}targets.Add(PathOf(pair.Value,wearer.transform));}
    PatchSelection(wearer,configs,constraints,shared,simulation,save);
    simulation.SetActive(compact);shared.SetActive(true);registerSimulation?.Invoke(simulation);
    if(compact)foreach(var pb in rig.GetComponentsInChildren<VRCPhysBone>(true))pb.allowGrabbing=VRCPhysBoneBase.AdvancedBool.False;
    Require(rig.GetComponentsInChildren<VRCPhysBone>(true).Length==sourcePhysics.Length-retained.Count,"physics was lost");
    foreach(var pb in rig.GetComponentsInChildren<VRCPhysBone>(true)){Require(!pb.rootTransform||pb.rootTransform.IsChildOf(rig),"external physics root");Require(pb.colliders.All(c=>c&&c.transform.IsChildOf(rig)),"external collider");pb.InitTransforms(true);}
    report.Add("Group="+options.name+" songs="+configs.Length+" sharedPhysBones="+(sourcePhysics.Length-retained.Count)+" retainedPerSong="+retained.Count+" sharedColliders="+rig.GetComponentsInChildren<VRCPhysBoneCollider>(true).Length+" poseConstraints="+constraints.Count+"; shared constraint/physics overlap=none; original dance and face timelines retained");
   }
   File.WriteAllLines(AnywhereMMDPlugin.Work+"shared-physics.txt",report);
  }
  static void PatchSelection(GameObject wearer,AnywhereMMD[] configs,List<VRCParentConstraint> constraints,GameObject shared,GameObject simulation,Action<Object> save){
   var descriptor=wearer.GetComponent<VRCAvatarDescriptor>();var layers=descriptor.baseAnimationLayers;int index=Array.FindIndex(layers,l=>l.type==VRCAvatarDescriptor.AnimLayerType.FX);Require(index>=0,"no FX layer");var original=layers[index].animatorController;var performance=configs.Select(c=>PathOf(c.performance,wearer.transform)).ToArray();var tracks=configs.Select(c=>PathOf(c.transform,wearer.transform)).ToArray();var overrides=new List<KeyValuePair<AnimationClip,AnimationClip>>();int selections=0,audiences=0;
   foreach(var clip in original.animationClips.Distinct()){
    var bindings=AnimationUtility.GetCurveBindings(clip);var activation=bindings.Where(b=>b.type==typeof(GameObject)&&b.propertyName=="m_IsActive").ToArray();var songCurves=performance.Select(p=>activation.Where(b=>b.path==p).ToArray()).ToArray();var audience=activation.Where(b=>b.path==tracks[0]).ToArray();bool song=songCurves.All(b=>b.Length==1);if(!song&&audience.Length==0)continue;
    var copy=Object.Instantiate(clip);copy.name=clip.name+" - shared dancer physics";
    if(song){int selected=-1;for(int i=0;i<configs.Length;i++){var curve=AnimationUtility.GetEditorCurve(clip,songCurves[i][0]);Require(curve.keys.All(k=>Mathf.Approximately(k.value,curve.keys[0].value)),"animated selection curve");if(curve.Evaluate(0)>.5f){Require(selected<0,"multiple songs selected");selected=i;}}foreach(var constraint in constraints)for(int i=0;i<configs.Length;i++)Curve(copy,PathOf(constraint.transform,wearer.transform),typeof(VRCParentConstraint),"Sources.source"+i+".Weight",i==selected?1:0);Curve(copy,PathOf(simulation.transform,wearer.transform),typeof(GameObject),"m_IsActive",selected>=0?1:0);if(selected>=0){var reset=new AnimationCurve(new Keyframe(0,0,0,float.PositiveInfinity),new Keyframe(.033334f,1,0,0),new Keyframe(.1f,1,0,0));AnimationUtility.SetEditorCurve(copy,EditorCurveBinding.FloatCurve(PathOf(simulation.transform,wearer.transform),typeof(GameObject),"m_IsActive"),reset);}selections++;}
    if(audience.Length>0){AnimationUtility.SetEditorCurve(copy,EditorCurveBinding.FloatCurve(PathOf(shared.transform,wearer.transform),typeof(GameObject),"m_IsActive"),AnimationUtility.GetEditorCurve(clip,audience[0]));audiences++;}
    save(copy);overrides.Add(new KeyValuePair<AnimationClip,AnimationClip>(clip,copy));
   }
   Require(selections>=configs.Length+1,"not all song-selection clips located: "+selections);var controller=ClothingSync.OverridePreserving(original,overrides,original.name+" - shared physics");save(controller);var layer=layers[index];layer.animatorController=controller;layers[index]=layer;descriptor.baseAnimationLayers=layers;
  }
 }
}
