using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using nadena.dev.ndmf;
using nadena.dev.ndmf.util;
using Object=UnityEngine.Object;
namespace Pokahina.AnywhereMMD.Editor {
 public sealed class MMDSharingState {public readonly List<Transform> dancers=new List<Transform>();public readonly List<GameObject> sharedSimulations=new List<GameObject>();}
 public static class MMDMeshSharing {
  sealed class Entry {public Mesh mesh;public string data;}
  static readonly Regex NameField=new Regex("(\\\"m_Name\\\"\\s*:\\s*)\\\"(?:\\\\.|[^\\\"\\\\])*\\\"");
  public static void Run(BuildContext context){
   var roots=context.GetState<MMDSharingState>().dancers.Where(t=>t).ToArray();if(roots.Length<2)return;
   var renderers=roots.SelectMany(t=>t.GetComponentsInChildren<SkinnedMeshRenderer>(true)).Distinct().ToArray();
   var filters=roots.SelectMany(t=>t.GetComponentsInChildren<MeshFilter>(true)).Distinct().ToArray();
   var meshes=renderers.Select(r=>r.sharedMesh).Concat(filters.Select(f=>f.sharedMesh)).Where(m=>m).Distinct().ToArray();
   var groups=new Dictionary<string,List<Entry>>();var replacements=new Dictionary<Mesh,Mesh>();long bytes=0;int skipped=0;
   foreach(var mesh in meshes){
    // Compare the complete serialized mesh payload, including skinning, bounds and morph frames.
    string data=EditorJsonUtility.ToJson(mesh);
    if(!data.Contains("m_VertexData")||!data.Contains("m_Shapes")||!data.Contains("m_BindPose")){skipped++;continue;}
    data=NameField.Replace(data,"$1\"\"");
    string hash;using(var sha=SHA256.Create())hash=Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(data)));
    if(!groups.TryGetValue(hash,out var candidates)){candidates=new List<Entry>();groups.Add(hash,candidates);}
    var match=candidates.FirstOrDefault(e=>String.Equals(e.data,data,StringComparison.Ordinal));
    if(match==null)candidates.Add(new Entry{mesh=mesh,data=data});else{replacements.Add(mesh,match.mesh);bytes+=UnityEngine.Profiling.Profiler.GetRuntimeMemorySizeLong(mesh);}
   }
   foreach(var renderer in renderers)if(renderer.sharedMesh&&replacements.TryGetValue(renderer.sharedMesh,out var shared))renderer.sharedMesh=shared;
   foreach(var filter in filters)if(filter.sharedMesh&&replacements.TryGetValue(filter.sharedMesh,out var shared))filter.sharedMesh=shared;
   // Never delete an asset still used by the wearer, animations, or another component.
   var referenced=new HashSet<Object>(context.AvatarRootObject.ReferencedAssets(traverseSaved:true,includeScene:false));int removed=0;
   foreach(var duplicate in replacements.Keys)if(!referenced.Contains(duplicate)&&context.IsTemporaryAsset(duplicate)){Object.DestroyImmediate(duplicate,true);removed++;}
   File.WriteAllText(AnywhereMMDPlugin.Work+"mesh-sharing.txt","Dancers="+roots.Length+" uniqueBefore="+meshes.Length+" identicalDuplicates="+replacements.Count+" removedTemporaryMeshes="+removed+" skippedUnknownPayload="+skipped+" estimatedMemoryBytesSaved="+bytes);
  }
 }
}
