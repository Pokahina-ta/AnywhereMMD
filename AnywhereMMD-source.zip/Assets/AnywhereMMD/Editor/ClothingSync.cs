using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using VRC.SDK3.Avatars.Components;
namespace Pokahina.AnywhereMMD.Editor {
 public static class ClothingSync {
  // Unity unwraps a nested AnimatorOverrideController. Carry every existing override explicitly.
  public static AnimatorOverrideController OverridePreserving(RuntimeAnimatorController original,IEnumerable<KeyValuePair<AnimationClip,AnimationClip>> replacements,string name){
   var changes=replacements.ToDictionary(p=>p.Key,p=>p.Value);
   var prior=new List<KeyValuePair<AnimationClip,AnimationClip>>();
   RuntimeAnimatorController underlying=original;
   if(original is AnimatorOverrideController inherited){inherited.GetOverrides(prior);underlying=inherited.runtimeAnimatorController;}
   var result=new AnimatorOverrideController(underlying){name=name};
   if(prior.Count>0)result.ApplyOverrides(prior.Select(p=>new KeyValuePair<AnimationClip,AnimationClip>(p.Key,changes.TryGetValue(p.Value?p.Value:p.Key,out var changed)?changed:p.Value)).ToList());
   else result.ApplyOverrides(changes.ToList());
   return result;
  }
  public static void Apply(GameObject wearer,Dictionary<string,List<string>> targets,Action<UnityEngine.Object> save){
   var desc=wearer.GetComponent<VRCAvatarDescriptor>();if(!desc)return;
   var layers=desc.baseAnimationLayers;int changes=0;
   for(int i=0;i<layers.Length;i++){
    if(layers[i].type!=VRCAvatarDescriptor.AnimLayerType.FX||!layers[i].animatorController)continue;
    var original=layers[i].animatorController;var overrides=new List<KeyValuePair<AnimationClip,AnimationClip>>();
    foreach(var clip in original.animationClips.Distinct()){
     var bindings=AnimationUtility.GetCurveBindings(clip).Where(b=>targets.ContainsKey(b.path)&&((b.type==typeof(GameObject)&&b.propertyName=="m_IsActive")||(typeof(Renderer).IsAssignableFrom(b.type)&&(b.propertyName=="m_Enabled"||b.propertyName.StartsWith("material.")))||((typeof(VRC.Dynamics.VRCPhysBoneBase).IsAssignableFrom(b.type)||typeof(VRC.Dynamics.VRCPhysBoneColliderBase).IsAssignableFrom(b.type))&&b.propertyName=="m_Enabled"))).ToArray();
     var objects=AnimationUtility.GetObjectReferenceCurveBindings(clip).Where(b=>targets.ContainsKey(b.path)&&typeof(Renderer).IsAssignableFrom(b.type)&&b.propertyName.StartsWith("m_Materials.Array.data[")).ToArray();
     if(bindings.Length==0&&objects.Length==0)continue;
     var copy=UnityEngine.Object.Instantiate(clip);copy.name=clip.name+" - MMD clothing";
     foreach(var b in bindings)foreach(var path in targets[b.path]){var dst=b;dst.path=path;AnimationUtility.SetEditorCurve(copy,dst,AnimationUtility.GetEditorCurve(clip,b));changes++;}
     foreach(var b in objects)foreach(var path in targets[b.path]){var dst=b;dst.path=path;AnimationUtility.SetObjectReferenceCurve(copy,dst,AnimationUtility.GetObjectReferenceCurve(clip,b));changes++;}
     save(copy);overrides.Add(new KeyValuePair<AnimationClip,AnimationClip>(clip,copy));
    }
    if(overrides.Count==0)continue;
    var controller=OverridePreserving(original,overrides,original.name+" - MMD clothing sync");save(controller);var layer=layers[i];layer.animatorController=controller;layers[i]=layer;
   }
   desc.baseAnimationLayers=layers;
   System.IO.File.WriteAllText(AnywhereMMDPlugin.Work+"clothing-sync.txt","Mirrored visibility curves: "+changes+"; source object paths: "+targets.Count);
  }
 }
}
