using System;
using UnityEngine;
using UnityEditor;

namespace Pokahina.AnywhereMMD.Editor {
 [Serializable] public sealed class MMDSong {
  public string title="Song";
  public AudioClip audio;
  public AnimationClip dance;
  public AnimationClip camera;
  public GameObject cameraRig;
 }
 [CreateAssetMenu(menuName="Anywhere MMD/Collection",fileName="MMD Collection")]
 public sealed class MMDCollection:ScriptableObject {
  public string menuName="Anywhere MMD";
  public MMDSong[] songs={new MMDSong()};
 }
 [CustomEditor(typeof(MMDCollection))] public sealed class MMDCollectionInspector:UnityEditor.Editor {
  public override void OnInspectorGUI(){
   serializedObject.Update();bool ja=MMDSettingsUI.Language();
   EditorGUILayout.PropertyField(serializedObject.FindProperty("menuName"),new GUIContent(ja?"メニュー名":"Menu name"));
   var rows=serializedObject.FindProperty("songs");
   for(int i=0;i<rows.arraySize;i++){
    var row=rows.GetArrayElementAtIndex(i);EditorGUILayout.BeginVertical(EditorStyles.helpBox);
    EditorGUILayout.LabelField((ja?"曲 ":"Song ")+(i+1),EditorStyles.boldLabel);
    string[] keys={"title","audio","dance","camera","cameraRig"};
    string[] labels=ja?new[]{"曲名","音源","ダンス（Humanoid）","カメラアニメーション","カメラRig Prefab（任意）"}:new[]{"Title","Audio","Dance (Humanoid)","Camera animation","Camera rig prefab (optional)"};
    for(int k=0;k<keys.Length;k++)EditorGUILayout.PropertyField(row.FindPropertyRelative(keys[k]),new GUIContent(labels[k]));
    if(GUILayout.Button(ja?"この曲を削除":"Remove song")){rows.DeleteArrayElementAtIndex(i);EditorGUILayout.EndVertical();break;}
    EditorGUILayout.EndVertical();
   }
   using(new EditorGUI.DisabledScope(rows.arraySize>=16))if(GUILayout.Button(ja?"曲を追加":"Add song")){
    int n=rows.arraySize;rows.InsertArrayElementAtIndex(n);var r=rows.GetArrayElementAtIndex(n);r.FindPropertyRelative("title").stringValue="Song "+(n+1);
    foreach(string key in new[]{"audio","dance","camera","cameraRig"})r.FindPropertyRelative(key).objectReferenceValue=null;
   }
   serializedObject.ApplyModifiedProperties();
   EditorGUILayout.HelpBox(ja?"音源・ダンス・カメラを指定し、Prefabを生成します。VMDは事前にUnity AnimationClipへ変換してください。カメラRig未指定時はPivot/Camera構成です。再生成は新しいフォルダーに保存し、既存のPrefabや元素材を上書きしません。":"Assign audio, dance and camera, then generate a prefab. Convert VMD to Unity AnimationClip first. Default rig: Pivot/Camera. Each generation creates a new folder without overwriting existing prefabs or source media.",MessageType.Info);
   using(new EditorGUI.DisabledScope(EditorApplication.isPlayingOrWillChangePlaymode))if(GUILayout.Button(ja?"Prefabを生成":"Generate prefab")){
    try{var result=MMDCollectionBuilder.Build((MMDCollection)target);Selection.activeObject=result;EditorGUIUtility.PingObject(result);}
    catch(Exception e){Debug.LogException(e);EditorUtility.DisplayDialog("Anywhere MMD",e.Message,"OK");}
   }
  }
 }
}
