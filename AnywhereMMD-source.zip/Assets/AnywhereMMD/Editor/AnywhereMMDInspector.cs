using UnityEditor;
using UnityEngine;
namespace Pokahina.AnywhereMMD.Editor {
 public static class MMDSettingsUI {
  const string Key="Pokahina.AnywhereMMD.Language";
  public static bool Language(){int lang=EditorPrefs.GetInt(Key,0);int next=EditorGUILayout.Popup("Language / 言語",lang,new[]{"日本語","English"});if(next!=lang)EditorPrefs.SetInt(Key,next);return next==0;}
  public static void Mode(SerializedObject data,bool ja){var prop=data.FindProperty("followAvatarSettings");int choice=EditorGUILayout.Popup(ja?"見た目の同期方式":"Appearance mode",prop.boolValue?0:1,ja?new[]{"同期型 — 本体に追従","非同期型 — 固定照明"}:new[]{"Follow avatar appearance","Independent — fixed lighting"});prop.boolValue=choice==0;
   EditorGUILayout.HelpBox(choice==0?(ja?"本体FXの衣装ON/OFF・マテリアル調整に追従します。ダンスとMMD表情は独立です。":"Follows outfit visibility and material changes driven by the avatar FX controller. Dance and MMD facial animation remain independent."):(ja?"生成時の衣装を使い、対応するlilToon/lilSSRTマテリアルは分身専用コピーで固定照明にします。本体は変更しません。":"Uses the visible outfit at build time. Supported lilToon/lilSSRT materials use fixed lighting on private copies; the original avatar is unchanged."),MessageType.Info);
  }
  public static void Quality(SerializedObject data,bool ja){EditorGUILayout.PropertyField(data.FindProperty("captureWidth"),new GUIContent(ja?"撮影解像度（横幅）":"Capture width"));EditorGUILayout.PropertyField(data.FindProperty("viewingRange"),new GUIContent(ja?"映像の表示距離 (m)":"Screen range (m)"));}
 }
 [CustomEditor(typeof(AnywhereMMDOptions))] public sealed class AnywhereMMDOptionsInspector:UnityEditor.Editor {
  public override void OnInspectorGUI(){serializedObject.Update();bool ja=MMDSettingsUI.Language();EditorGUILayout.LabelField(ja?"どこでもMMD — 共通設定":"Anywhere MMD — Collection settings",EditorStyles.boldLabel);MMDSettingsUI.Mode(serializedObject,ja);MMDSettingsUI.Quality(serializedObject,ja);EditorGUILayout.PropertyField(serializedObject.FindProperty("keepDancerGrabbing"),new GUIContent(ja?"分身の髪・服のつかみ操作を残す":"Keep dancer hair/outfit grabbing"));EditorGUILayout.HelpBox(ja?"複数曲の分身で共用する揺れに適用。OFFでも通常の揺れとコライダーは残ります。本体と指の設定は変更しません。ONではPhysBoneの数が増え、アップロード上限を超える場合があります。":"Applies to shared physics in multi-song collections. Normal motion and colliders remain enabled when off. The original avatar and finger settings are unchanged. Enabling grabbing may exceed the PhysBone upload limit.",MessageType.Info);EditorGUILayout.HelpBox(ja?"このPrefab内の全曲に適用します。変更後は再アップロードが必要です。":"Applies to every song in this prefab. Re-upload after changing these settings.",MessageType.None);serializedObject.ApplyModifiedProperties();}
 }
 [CustomEditor(typeof(AnywhereMMD))] public sealed class AnywhereMMDInspector:UnityEditor.Editor {
  public override void OnInspectorGUI(){serializedObject.Update();bool ja=MMDSettingsUI.Language();EditorGUILayout.LabelField("Anywhere MMD",EditorStyles.boldLabel);var inherited=((AnywhereMMD)target).GetComponentInParent<AnywhereMMDOptions>();
   if(inherited)EditorGUILayout.HelpBox(ja?"同期方式と画質は親の共通設定から引き継ぎます。":"Appearance mode and quality are inherited from the parent collection settings.",MessageType.Info);
   using(new EditorGUI.DisabledScope(inherited)){MMDSettingsUI.Mode(serializedObject,ja);MMDSettingsUI.Quality(serializedObject,ja);}
   EditorGUILayout.PropertyField(serializedObject.FindProperty("autoFitCamera"),new GUIContent(ja?"目線高に合わせてカメラ補正":"Fit camera to eye height"));
   if(serializedObject.FindProperty("autoFitCamera").boolValue){EditorGUILayout.PropertyField(serializedObject.FindProperty("cameraReferenceHeight"),new GUIContent(ja?"基準目線高 (m)":"Reference eye height (m)"));EditorGUILayout.PropertyField(serializedObject.FindProperty("cameraFitMultiplier"),new GUIContent(ja?"画角の広さ補正":"Framing scale"));EditorGUILayout.PropertyField(serializedObject.FindProperty("cameraHeightOffset"),new GUIContent(ja?"高さ微調整 (m)":"Vertical offset (m)"));}
   EditorGUILayout.HelpBox(ja?"PC向け。相手側でカメラが許可されている必要があります。":"PC only. The viewer must allow avatar cameras.",MessageType.None);serializedObject.ApplyModifiedProperties();
  }
 }
}