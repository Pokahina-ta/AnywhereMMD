using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using nadena.dev.ndmf;
using VRC.SDK3.Dynamics.PhysBone.Components;
using Object=UnityEngine.Object;
[assembly: ExportsPlugin(typeof(Pokahina.AnywhereMMD.Editor.AnywhereMMDPlugin))]
namespace Pokahina.AnywhereMMD.Editor {
 public sealed class AnywhereMMDPlugin:Plugin<AnywhereMMDPlugin>{
  public static string Work {get {var p=System.IO.Path.GetFullPath("Library/AnywhereMMD/")+System.IO.Path.DirectorySeparatorChar;System.IO.Directory.CreateDirectory(p);return p;}}
  public override string QualifiedName=>"pokahina.anywhere-mmd";
  public override string DisplayName=>"Anywhere MMD / dance double";
  protected override void Configure(){InPhase(BuildPhase.Transforming).AfterPlugin("nadena.dev.modular-avatar").BeforePlugin("com.anatawa12.avatar-optimizer").Run("Create wearer-specific dancer",ctx=>{
   var settings=ctx.AvatarRootObject.GetComponentsInChildren<AnywhereMMD>(true);var targets=new Dictionary<string,List<string>>();var captures=new Dictionary<string,RenderTexture>();var created=new Dictionary<AnywhereMMD,GameObject>();
   foreach(var setting in settings){
    var options=setting.GetComponentInParent<AnywhereMMDOptions>();if(options){setting.followAvatarSettings=options.followAvatarSettings;setting.captureWidth=options.captureWidth;setting.viewingRange=options.viewingRange;}
    RenderTexture shared=null;string key=setting.captureGroup+"/"+setting.captureWidth;if(!string.IsNullOrEmpty(setting.captureGroup))captures.TryGetValue(key,out shared);
    var dancer=BuildDouble(ctx.AvatarRootObject,setting,asset=>ctx.AssetSaver.SaveAsset(asset),targets,shared);created.Add(setting,dancer);ctx.GetState<MMDSharingState>().dancers.Add(dancer.transform);if(!string.IsNullOrEmpty(setting.captureGroup))captures[key]=setting.captureCamera.targetTexture;
   }
   MMDSharedPhysics.Apply(ctx.AvatarRootObject,created,targets,asset=>ctx.AssetSaver.SaveAsset(asset),simulation=>ctx.GetState<MMDSharingState>().sharedSimulations.Add(simulation));ClothingSync.Apply(ctx.AvatarRootObject,targets,asset=>ctx.AssetSaver.SaveAsset(asset));foreach(var simulation in ctx.GetState<MMDSharingState>().sharedSimulations){var fx=ctx.AvatarRootObject.GetComponent<VRC.SDK3.Avatars.Components.VRCAvatarDescriptor>().baseAnimationLayers.First(l=>l.type==VRC.SDK3.Avatars.Components.VRCAvatarDescriptor.AnimLayerType.FX).animatorController;string simulationPath=AnimationUtility.CalculateTransformPath(simulation.transform,ctx.AvatarRootTransform);int bindings=fx.animationClips.Distinct().SelectMany(AnimationUtility.GetCurveBindings).Count(b=>b.path==simulationPath&&b.type==typeof(GameObject)&&b.propertyName=="m_IsActive");if(bindings<2)throw new Exception("Shared-physics selection overrides were lost");}foreach(var setting in settings)Object.DestroyImmediate(setting);foreach(var options in ctx.AvatarRootObject.GetComponentsInChildren<AnywhereMMDOptions>(true))Object.DestroyImmediate(options);
  });InPhase(BuildPhase.Optimizing).AfterPlugin("com.anatawa12.avatar-optimizer").Run("Share identical MMD meshes",ctx=>{MMDMeshSharing.Run(ctx);foreach(var simulation in ctx.GetState<MMDSharingState>().sharedSimulations)if(simulation)simulation.SetActive(false);});}
  public static float EstimateHeight(Animator human){
   var descriptor=human.GetComponent<VRC.SDK3.Avatars.Components.VRCAvatarDescriptor>();
   if(descriptor&&descriptor.ViewPosition.y>.1f)return descriptor.ViewPosition.y;
   var left=human.GetBoneTransform(HumanBodyBones.LeftEye);var right=human.GetBoneTransform(HumanBodyBones.RightEye);
   var eye=left?left:right;var head=human.GetBoneTransform(HumanBodyBones.Head);
   if(!eye&&!head)throw new Exception("Camera fitting requires avatar View Position or eye/head bones.");
   Vector3 point=left&&right?(left.position+right.position)*.5f:(eye?eye:head).position;
   float height=human.transform.InverseTransformPoint(point).y;
   if(float.IsNaN(height)||float.IsInfinity(height)||height<.1f)throw new Exception("Camera fitting: invalid eye height; check standing pose and View Position.");
   return height;
  }
  public static void CopyPhysBones(GameObject wearer,Dictionary<Transform,Transform> map){
   // Create every destination first: collider references can point forward in the hierarchy.
   var objects=new Dictionary<Object,Object>();
   foreach(var pair in map){objects[pair.Key]=pair.Value;objects[pair.Key.gameObject]=pair.Value.gameObject;}
   var pairs=new List<KeyValuePair<Component,Component>>();
   foreach(var source in wearer.GetComponentsInChildren<VRCPhysBoneCollider>(true)){
    if(!map.TryGetValue(source.transform,out var target))continue;
    if(source.rootTransform&&!map.ContainsKey(source.rootTransform)){Debug.LogWarning("MMD: skipped collider with a root outside the dancer: "+source.name,source);continue;}
    var copy=target.gameObject.AddComponent<VRCPhysBoneCollider>();objects[source]=copy;pairs.Add(new KeyValuePair<Component,Component>(source,copy));
   }
   foreach(var source in wearer.GetComponentsInChildren<VRCPhysBone>(true)){
    if(!map.TryGetValue(source.transform,out var target))continue;
    if(source.rootTransform&&!map.ContainsKey(source.rootTransform)){Debug.LogWarning("MMD: skipped PhysBone with a root outside the dancer: "+source.name,source);continue;}
    var copy=target.gameObject.AddComponent<VRCPhysBone>();objects[source]=copy;pairs.Add(new KeyValuePair<Component,Component>(source,copy));
   }
   foreach(var pair in pairs){
    EditorUtility.CopySerialized(pair.Key,pair.Value);
    var serialized=new SerializedObject(pair.Value);var property=serialized.GetIterator();
    while(property.Next(true)){
     if(property.propertyType!=SerializedPropertyType.ObjectReference||property.propertyPath=="m_Script"||property.propertyPath=="m_GameObject"||property.propertyPath=="m_CorrespondingSourceObject"||property.propertyPath=="m_PrefabInstance"||property.propertyPath=="m_PrefabAsset")continue;
     var reference=property.objectReferenceValue;if(!reference)continue;
     if(objects.TryGetValue(reference,out var mapped))property.objectReferenceValue=mapped;
     else if(reference is Component||reference is GameObject){property.objectReferenceValue=null;Debug.LogWarning("MMD: removed external physics reference "+property.propertyPath+" on "+pair.Key.name,pair.Key);}
    }
    serialized.ApplyModifiedPropertiesWithoutUndo();
    if(pair.Value is VRCPhysBone physics){
     // Each dancer simulates its own hair/clothes and never writes the wearer's interaction parameters.
     physics.parameter="";physics.isAnimated=true;physics.resetWhenDisabled=true;
     physics.colliders=physics.colliders.Where(c=>c).ToList();
    }
   }
  }
  public static GameObject BuildDouble(GameObject wearer,AnywhereMMD config,Action<Object> save,Dictionary<string,List<string>> visibilityTargets=null,RenderTexture sharedCapture=null){
   var options=config.GetComponentInParent<AnywhereMMDOptions>();if(options){config.followAvatarSettings=options.followAvatarSettings;config.captureWidth=options.captureWidth;config.viewingRange=options.viewingRange;}
   if(!config.stage||!config.screen||!config.captureCamera||!config.danceController)throw new Exception("Anywhere MMD: required setup is missing.");
   var human=wearer.GetComponent<Animator>();if(!human||!human.avatar||!human.avatar.isHuman)throw new Exception("Anywhere MMD requires a Humanoid avatar.");
   if(config.stage.Find("Dancer"))throw new Exception("Dance double already exists; regenerate from the original avatar.");
   var map=new Dictionary<Transform,Transform>();
   var dancer=new GameObject("Dancer");dancer.SetActive(false);dancer.transform.SetParent(config.stage,false);map[wearer.transform]=dancer.transform;
   foreach(var t in wearer.GetComponentsInChildren<Transform>(true)){
    if(t==wearer.transform||t.IsChildOf(config.transform)||t.GetComponentInParent<AnywhereMMD>()||t.GetComponentInParent<AnywhereMMDOptions>())continue;
    if(!map.TryGetValue(t.parent,out var parent))continue;
    var c=new GameObject(t.name);c.transform.SetParent(parent,false);c.transform.localPosition=t.localPosition;c.transform.localRotation=t.localRotation;c.transform.localScale=t.localScale;c.SetActive(t.gameObject.activeSelf);map[t]=c.transform;
   }
   CopyPhysBones(wearer,map);
   var filmMaterials=new Dictionary<Material,Material>();int count=0;
   foreach(var r in wearer.GetComponentsInChildren<Renderer>(true)){
    if(!map.TryGetValue(r.transform,out var target))continue;if(!config.followAvatarSettings&&(!r.enabled||!r.gameObject.activeInHierarchy))continue;
    Renderer copy=null;
    if(r is SkinnedMeshRenderer sk){var dst=target.gameObject.AddComponent<SkinnedMeshRenderer>();EditorUtility.CopySerialized(sk,dst);dst.bones=sk.bones.Select(b=>b&&map.ContainsKey(b)?map[b]:null).ToArray();dst.rootBone=sk.rootBone&&map.ContainsKey(sk.rootBone)?map[sk.rootBone]:dancer.transform;dst.updateWhenOffscreen=true;copy=dst;}
    else if(r is MeshRenderer mr){var mf=r.GetComponent<MeshFilter>();if(!mf||!mf.sharedMesh)continue;target.gameObject.AddComponent<MeshFilter>().sharedMesh=mf.sharedMesh;var dst=target.gameObject.AddComponent<MeshRenderer>();EditorUtility.CopySerialized(mr,dst);copy=dst;}
    if(copy){if(!config.followAvatarSettings){copy.sharedMaterials=copy.sharedMaterials.Select(material=>{if(!material||!material.HasProperty("_AsUnlit"))return material;if(filmMaterials.TryGetValue(material,out var existing))return existing;var film=new Material(material){name=material.name+" - MMD fixed lighting"};foreach(var property in new[]{"_AsUnlit","_LightMinLimit","_LightMaxLimit"})if(film.HasProperty(property))film.SetFloat(property,1);foreach(var property in new[]{"_UseShadow","_UseReflection","_ApplySpecular","_ApplySpecularFA","_LilSSRTAO","_LilSSRTAOStrength","_MatCapEnableLighting","_MatCap2ndEnableLighting","_RimEnableLighting","_OutlineEnableLighting"})if(film.HasProperty(property))film.SetFloat(property,0);save(film);filmMaterials.Add(material,film);return film;}).ToArray();copy.receiveShadows=false;copy.lightProbeUsage=UnityEngine.Rendering.LightProbeUsage.Off;copy.reflectionProbeUsage=UnityEngine.Rendering.ReflectionProbeUsage.Off;}copy.probeAnchor=r.probeAnchor?r.probeAnchor:(human.GetBoneTransform(HumanBodyBones.Chest)?human.GetBoneTransform(HumanBodyBones.Chest):wearer.transform);copy.shadowCastingMode=config.followAvatarSettings?UnityEngine.Rendering.ShadowCastingMode.On:UnityEngine.Rendering.ShadowCastingMode.Off;count++;}
   }
   if(config.followAvatarSettings&&visibilityTargets!=null)foreach(var pair in map){if(pair.Key==wearer.transform||(pair.Value.GetComponentsInChildren<Renderer>(true).Length==0&&pair.Value.GetComponentsInChildren<VRCPhysBone>(true).Length==0&&pair.Value.GetComponentsInChildren<VRCPhysBoneCollider>(true).Length==0))continue;string sourcePath=AnimationUtility.CalculateTransformPath(pair.Key,wearer.transform);if(!visibilityTargets.TryGetValue(sourcePath,out var paths)){paths=new List<string>();visibilityTargets.Add(sourcePath,paths);}paths.Add(AnimationUtility.CalculateTransformPath(pair.Value,wearer.transform));}
   if(count==0)throw new Exception("No visible avatar meshes were found.");
   var anim=dancer.AddComponent<Animator>();anim.avatar=human.avatar;anim.runtimeAnimatorController=config.danceController;anim.applyRootMotion=true;anim.cullingMode=AnimatorCullingMode.AlwaysAnimate;anim.updateMode=AnimatorUpdateMode.Normal;
   foreach(var timeline in config.performance.GetComponentsInChildren<Animator>(true)){timeline.cullingMode=AnimatorCullingMode.AlwaysAnimate;timeline.updateMode=AnimatorUpdateMode.Normal;}
   foreach(var sound in config.performance.GetComponentsInChildren<AudioSource>(true)){sound.spatialBlend=0;sound.spatialize=false;sound.panStereo=0;sound.bypassReverbZones=true;sound.reverbZoneMix=0;sound.dopplerLevel=0;sound.pitch=1;var spatial=sound.GetComponent<VRC.SDKBase.VRC_SpatialAudioSource>();if(!spatial)spatial=sound.gameObject.AddComponent<VRC.SDK3.Avatars.Components.VRCSpatialAudioSource>();spatial.EnableSpatialization=false;spatial.Gain=0;spatial.Near=0;spatial.Far=config.viewingRange;spatial.UseAudioSourceVolumeCurve=true;sound.maxDistance=config.viewingRange;sound.minDistance=Mathf.Min(4,config.viewingRange*.5f);}
   var rig=config.stage.Find("Rig");if(config.autoFitCamera&&rig){
    float height=EstimateHeight(human);float fit=height/Mathf.Max(.1f,config.cameraReferenceHeight)*config.cameraFitMultiplier;
    rig.localScale=Vector3.one*fit;rig.localPosition=new Vector3(0,config.cameraHeightOffset,0);
    Debug.Log("Anywhere MMD camera fit: reference eye height="+height.ToString("F3")+", ratio="+fit.ToString("F3"),config);
   }
   var backdrop=config.stage.Find("Private backdrop");if(backdrop){var background=backdrop.GetComponent<Renderer>();if(background){background.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;background.receiveShadows=false;background.lightProbeUsage=UnityEngine.Rendering.LightProbeUsage.Off;background.reflectionProbeUsage=UnityEngine.Rendering.ReflectionProbeUsage.Off;}}
   // Screen-space AO radii are world-space distances: preserve full-size geometry for lilSSRT.
   if(dancer.GetComponentsInChildren<Renderer>(true).SelectMany(r=>r.sharedMaterials).Any(m=>m&&m.shader&&m.shader.name.IndexOf("lilSSRT",StringComparison.OrdinalIgnoreCase)>=0))config.stageScale=1;
   config.stage.localPosition=config.stageOffset;config.stage.localScale=Vector3.one*config.stageScale;
   config.captureCamera.renderingPath=RenderingPath.DeferredShading;config.captureCamera.depthTextureMode=DepthTextureMode.Depth;config.captureCamera.allowMSAA=false;
   config.captureCamera.nearClipPlane=.005f;config.captureCamera.farClipPlane=80*config.stageScale;
   config.captureCamera.cullingMask=(1<<0)|(1<<9)|(1<<10)|(1<<18);config.captureCamera.useOcclusionCulling=false;
   var rt=sharedCapture?sharedCapture:new RenderTexture(config.captureWidth,Mathf.RoundToInt(config.captureWidth*9f/16f),24,RenderTextureFormat.ARGB32){name="Anywhere MMD - wearer capture",antiAliasing=1,filterMode=FilterMode.Bilinear,useMipMap=false,autoGenerateMips=false};if(!sharedCapture)save(rt);config.captureCamera.targetTexture=rt;
   var mat=new Material(config.screen.sharedMaterial){name="Anywhere MMD - wearer screen"};mat.SetTexture("_SceneTex",rt);mat.SetFloat("_Range",config.viewingRange);mat.SetFloat("_CaptureFar",config.captureCamera.farClipPlane);save(mat);config.screen.sharedMaterial=mat;
   FaceRetarget.Apply(wearer,dancer,config,save);dancer.SetActive(true);return dancer;
  }
 }
}



