using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEditor.Animations;
using nadena.dev.modular_avatar.core;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Object=UnityEngine.Object;

namespace Pokahina.AnywhereMMD.Editor {
 public static class MMDCollectionBuilder {
  static GameObject Child(string name,Transform parent){var g=new GameObject(name);g.transform.SetParent(parent,false);return g;}
  static T Save<T>(T obj,string path)where T:Object{AssetDatabase.CreateAsset(obj,path);return obj;}
  static void Curve(AnimationClip clip,string path,Type type,string property,float value,float duration){AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve(path,type,property),AnimationCurve.Constant(0,duration,value));}
  static AnimatorController Controller(string path,AnimationClip motion){var c=AnimatorController.CreateAnimatorControllerAtPath(path);var s=c.layers[0].stateMachine.AddState("Play");s.motion=motion;s.writeDefaultValues=false;c.layers[0].stateMachine.defaultState=s;return c;}
  static void Merge(GameObject root,AnimatorController controller){var m=root.AddComponent<ModularAvatarMergeAnimator>();m.animator=controller;m.layerType=VRCAvatarDescriptor.AnimLayerType.FX;m.pathMode=MergeAnimatorPathMode.Relative;m.matchAvatarWriteDefaults=true;}
  static void Transition(AnimatorState from,AnimatorState to,string parameter,int value){var t=from.AddTransition(to);t.hasExitTime=false;t.duration=0;t.AddCondition(AnimatorConditionMode.Equals,value,parameter);}
  static GameObject Rig(MMDSong song,Transform parent){
   GameObject rig;
   if(song.cameraRig){rig=Object.Instantiate(song.cameraRig,parent,false);rig.name="Rig";}
   else {rig=Child("Rig",parent);var p=Child("Pivot",rig.transform);var c=Child("Camera",p.transform);c.transform.localPosition=new Vector3(0,1.1f,-3);c.transform.localRotation=Quaternion.Euler(0,0,0);c.AddComponent<Camera>();}
   return rig;
  }
  public static void Validate(MMDCollection collection){
   if(!collection||collection.songs==null||collection.songs.Length<1||collection.songs.Length>16)throw new Exception("Choose 1–16 songs / 曲数は1〜16曲です。");
   foreach(var song in collection.songs){
    if(song==null||!song.audio||!song.dance||!song.camera)throw new Exception("Each song needs audio, dance and camera clips / 各曲の音源・ダンス・カメラを指定してください。");
    if(!song.dance.humanMotion||song.dance.legacy)throw new Exception("Dance must be a non-Legacy Humanoid clip: "+song.title);
    if(song.audio.length<=0||song.camera.length<=0)throw new Exception("Empty audio or camera clip: "+song.title);
    if(!(AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(song.audio)) is AudioImporter))throw new Exception("Audio must be an imported audio file: "+song.title);
    GameObject rig=null;try{
     rig=Rig(song,null);
     if(rig.GetComponentsInChildren<Camera>(true).Length!=1)throw new Exception("Camera rig must contain exactly one Camera: "+song.title);
     if(rig.GetComponentsInChildren<MonoBehaviour>(true).Length>0||rig.GetComponentsInChildren<Animator>(true).Length>0||rig.GetComponentsInChildren<AudioSource>(true).Length>0||rig.GetComponentsInChildren<Renderer>(true).Length>0)throw new Exception("Camera rig must contain only transforms and one Camera (no scripts, animators, renderers or audio): "+song.title);
     if(rig.GetComponentsInChildren<Component>(true).Any(c=>!c||(!(c is Transform)&&!(c is Camera)&&!(c is AudioListener))))throw new Exception("Unsupported camera rig component: "+song.title);
     if(rig.GetComponentsInChildren<Transform>(true).Any(t=>!t.gameObject.activeSelf))throw new Exception("All camera rig objects must be active: "+song.title);
     if(AnimationUtility.GetObjectReferenceCurveBindings(song.camera).Length>0)throw new Exception("Camera object-reference curves are not supported: "+song.title);
     var bindings=AnimationUtility.GetCurveBindings(song.camera);if(bindings.Length==0)throw new Exception("Camera clip has no curves: "+song.title);
     foreach(var b in bindings){
      if(b.type!=typeof(Transform)&&b.type!=typeof(Camera))throw new Exception("Camera clip supports Transform/Camera curves only: "+b.propertyName);
      var t=string.IsNullOrEmpty(b.path)?rig.transform:rig.transform.Find(b.path);
      if(!t||!t.GetComponent(b.type))throw new Exception("Camera binding not found in rig: "+song.title+" / "+b.path);
     }
    }finally{if(rig)Object.DestroyImmediate(rig);}
   }
  }
  public static GameObject Build(MMDCollection collection){
   Validate(collection);
   var screenShader=Shader.Find("Pokahina/Dance Lounge Screen");var backdropShader=Shader.Find("Pokahina/Dance Lounge Backdrop");
   if(!screenShader||!backdropShader)throw new Exception("Included screen/background shaders are missing.");
   if(!AssetDatabase.IsValidFolder("Assets/AnywhereMMD-Generated"))AssetDatabase.CreateFolder("Assets","AnywhereMMD-Generated");
   string id=Guid.NewGuid().ToString("N").Substring(0,12);string folder="Assets/AnywhereMMD-Generated/Collection-"+id;AssetDatabase.CreateFolder("Assets/AnywhereMMD-Generated","Collection-"+id);
   string songParameter="PKH/MMD/"+id+"/Song",modeParameter="PKH/MMD/"+id+"/Display";
   var root=new GameObject(string.IsNullOrWhiteSpace(collection.menuName)?"Anywhere MMD":collection.menuName);root.AddComponent<AnywhereMMDOptions>();
   try{
    var rt=Save(new RenderTexture(2560,1440,24,RenderTextureFormat.ARGB32){name="Shared Capture",vrUsage=VRTextureUsage.None,filterMode=FilterMode.Bilinear},folder+"/Capture.renderTexture");
    int count=collection.songs.Length;var configs=new AnywhereMMD[count];
    for(int i=0;i<count;i++){
     var song=collection.songs[i];string track="Track"+(i+1).ToString("00"),dir=folder+"/"+track;AssetDatabase.CreateFolder(folder,track);
     var part=Child(track,root.transform);var perf=Child("Performance",part.transform);var stage=Child("Stage",perf.transform);stage.transform.localPosition=new Vector3(0,256,0);stage.transform.localScale=Vector3.one*.02f;
     var fit=Child("Rig",stage.transform);var rig=Rig(song,fit.transform);rig.name="Motion";var cam=rig.GetComponentInChildren<Camera>(true);cam.stereoTargetEye=StereoTargetEyeMask.None;cam.enabled=false;cam.targetTexture=rt;cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=new Color(.015f,.005f,.02f);cam.nearClipPlane=.005f;cam.farClipPlane=1.6f;cam.aspect=16f/9f;cam.depth=-50;cam.allowHDR=false;cam.allowMSAA=false;cam.useOcclusionCulling=false;
     foreach(var listener in rig.GetComponentsInChildren<AudioListener>(true))Object.DestroyImmediate(listener);
     var film=new AnimationClip{name=song.title+" Camera",frameRate=song.camera.frameRate};
     foreach(var b in AnimationUtility.GetCurveBindings(song.camera)){var dst=b;dst.path="Stage/Rig/Motion"+(string.IsNullOrEmpty(b.path)?"":"/"+b.path);AnimationUtility.SetEditorCurve(film,dst,AnimationUtility.GetEditorCurve(song.camera,b));}
     Curve(film,AnimationUtility.CalculateTransformPath(cam.transform,perf.transform),typeof(Camera),"m_Enabled",1,song.audio.length);Save(film,dir+"/Performance.anim");perf.AddComponent<Animator>().runtimeAnimatorController=Controller(dir+"/Performance.controller",film);
     var body=Object.Instantiate(song.dance);body.name=song.title+" Dance";var settings=AnimationUtility.GetAnimationClipSettings(body);settings.loopTime=false;AnimationUtility.SetAnimationClipSettings(body,settings);Save(body,dir+"/Body.anim");
     var screen=GameObject.CreatePrimitive(PrimitiveType.Quad);screen.name="Screen";screen.transform.SetParent(perf.transform,false);Object.DestroyImmediate(screen.GetComponent<Collider>());
     var mesh=Object.Instantiate(screen.GetComponent<MeshFilter>().sharedMesh);mesh.bounds=new Bounds(Vector3.zero,Vector3.one*200);screen.GetComponent<MeshFilter>().sharedMesh=Save(mesh,dir+"/Screen Mesh.asset");
     var mat=Save(new Material(screenShader),dir+"/Screen.mat");mat.SetTexture("_SceneTex",rt);var renderer=screen.GetComponent<Renderer>();renderer.sharedMaterial=mat;renderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;
     var backdrop=GameObject.CreatePrimitive(PrimitiveType.Sphere);backdrop.name="Private backdrop";backdrop.transform.SetParent(stage.transform,false);backdrop.transform.localScale=Vector3.one*128;Object.DestroyImmediate(backdrop.GetComponent<Collider>());backdrop.GetComponent<Renderer>().sharedMaterial=Save(new Material(backdropShader),dir+"/Backdrop.mat");
     string audioPath=AssetDatabase.GetAssetPath(song.audio),audioCopy=dir+"/Music"+Path.GetExtension(audioPath);if(!AssetDatabase.CopyAsset(audioPath,audioCopy))throw new Exception("Could not copy audio: "+song.title);
     var importer=(AudioImporter)AssetImporter.GetAtPath(audioCopy);var sample=importer.defaultSampleSettings;sample.loadType=AudioClipLoadType.DecompressOnLoad;importer.defaultSampleSettings=sample;importer.loadInBackground=false;var serialized=new SerializedObject(importer);var preload=serialized.FindProperty("m_DefaultSettings.preloadAudioData");if(preload!=null){preload.boolValue=true;serialized.ApplyModifiedPropertiesWithoutUndo();}importer.SaveAndReimport();
     var audio=Child("Music",perf.transform).AddComponent<AudioSource>();audio.clip=AssetDatabase.LoadAssetAtPath<AudioClip>(audioCopy);audio.playOnAwake=true;audio.loop=false;audio.spatialBlend=0;audio.spatialize=false;audio.dopplerLevel=0;audio.volume=.7f;audio.bypassReverbZones=true;
     var cfg=part.AddComponent<AnywhereMMD>();cfg.songFolder=dir+"/";cfg.captureGroup=id;cfg.performance=perf.transform;cfg.stage=stage.transform;cfg.captureCamera=cam;cfg.screen=renderer;cfg.danceController=Controller(dir+"/Dance.controller",body);configs[i]=cfg;perf.SetActive(false);
    }
    var fx=AnimatorController.CreateAnimatorControllerAtPath(folder+"/Song Selection.controller");fx.AddParameter(songParameter,AnimatorControllerParameterType.Int);var machine=fx.layers[0].stateMachine;
    var stopClip=new AnimationClip{name="Stop"};foreach(var cfg in configs)Curve(stopClip,AnimationUtility.CalculateTransformPath(cfg.performance,root.transform),typeof(GameObject),"m_IsActive",0,.1f);Save(stopClip,folder+"/Stop.anim");
    var stop=machine.AddState("Stopped");stop.motion=stopClip;stop.writeDefaultValues=false;machine.defaultState=stop;var playing=new AnimatorState[count];var finished=new AnimatorState[count];
    for(int i=0;i<count;i++){
     var clip=new AnimationClip{name=collection.songs[i].title+" Selected"};for(int k=0;k<count;k++)Curve(clip,AnimationUtility.CalculateTransformPath(configs[k].performance,root.transform),typeof(GameObject),"m_IsActive",i==k?1:0,collection.songs[i].audio.length);Save(clip,folder+"/Track"+(i+1).ToString("00")+"/Selected.anim");
     playing[i]=machine.AddState("Song "+(i+1));playing[i].motion=clip;playing[i].writeDefaultValues=false;finished[i]=machine.AddState("Finished "+(i+1));finished[i].motion=stopClip;finished[i].writeDefaultValues=false;var end=playing[i].AddTransition(finished[i]);end.hasExitTime=true;end.exitTime=1;end.duration=0;
    }
    foreach(var from in new[]{stop}.Concat(playing).Concat(finished)){if(from!=stop)Transition(from,stop,songParameter,0);for(int i=0;i<count;i++)if(from!=playing[i]&&from!=finished[i])Transition(from,playing[i],songParameter,i+1);}
    Merge(root,fx);var parameters=root.AddComponent<ModularAvatarParameters>();foreach(string p in new[]{songParameter,modeParameter})parameters.parameters.Add(new ParameterConfig{nameOrPrefix=p,syncType=ParameterSyncType.Int,saved=false,defaultValue=0,hasExplicitDefaultValue=true});
    var top=Save(ScriptableObject.CreateInstance<VRCExpressionsMenu>(),folder+"/Main Menu.asset");var hub=Save(ScriptableObject.CreateInstance<VRCExpressionsMenu>(),folder+"/Hub Menu.asset");var display=Save(ScriptableObject.CreateInstance<VRCExpressionsMenu>(),folder+"/Display Menu.asset");
    var pages=Enumerable.Range(0,(count+4)/5).Select(n=>Save(ScriptableObject.CreateInstance<VRCExpressionsMenu>(),folder+"/Songs "+(n+1)+".asset")).ToArray();
    for(int p=0;p<pages.Length;p++){pages[p].controls.Add(new VRCExpressionsMenu.Control{name="停止 / Stop",type=VRCExpressionsMenu.Control.ControlType.Button,parameter=new VRCExpressionsMenu.Control.Parameter{name=songParameter},value=0});for(int i=p*5;i<Math.Min(count,p*5+5);i++)pages[p].controls.Add(new VRCExpressionsMenu.Control{name=collection.songs[i].title,type=VRCExpressionsMenu.Control.ControlType.Toggle,parameter=new VRCExpressionsMenu.Control.Parameter{name=songParameter},value=i+1});if(p+1<pages.Length)pages[p].controls.Add(new VRCExpressionsMenu.Control{name="次へ / Next",type=VRCExpressionsMenu.Control.ControlType.SubMenu,subMenu=pages[p+1]});}
    hub.controls.Add(new VRCExpressionsMenu.Control{name="曲選択 / Songs",type=VRCExpressionsMenu.Control.ControlType.SubMenu,subMenu=pages[0]});hub.controls.Add(new VRCExpressionsMenu.Control{name="表示設定 / Display",type=VRCExpressionsMenu.Control.ControlType.SubMenu,subMenu=display});top.controls.Add(new VRCExpressionsMenu.Control{name=root.name,type=VRCExpressionsMenu.Control.ControlType.SubMenu,subMenu=hub});
    string[] modes={"Camera Only","Local","Local + Camera Only"};for(int i=0;i<3;i++)display.controls.Add(new VRCExpressionsMenu.Control{name=modes[i],type=VRCExpressionsMenu.Control.ControlType.Toggle,parameter=new VRCExpressionsMenu.Control.Parameter{name=modeParameter},value=i+1});
    foreach(var menu in pages.Concat(new[]{top,hub,display}))EditorUtility.SetDirty(menu);root.AddComponent<ModularAvatarMenuInstaller>().menuToAppend=top;
    Display(root,configs,folder,modeParameter);var result=PrefabUtility.SaveAsPrefabAsset(root,folder+"/Anywhere MMD.prefab");AssetDatabase.SaveAssets();return result;
   }finally{Object.DestroyImmediate(root);}
  }
  static AnimatorState State(AnimatorStateMachine sm,string name,AnimationClip clip){var s=sm.AddState(name);s.motion=clip;s.writeDefaultValues=false;return s;}
  static void To(AnimatorStateMachine sm,AnimatorState state,string parameter,int mode,bool? local=null){var t=sm.AddAnyStateTransition(state);t.hasExitTime=false;t.duration=0;t.canTransitionToSelf=false;if(mode>=0)t.AddCondition(AnimatorConditionMode.Equals,mode,parameter);if(local.HasValue)t.AddCondition(local.Value?AnimatorConditionMode.If:AnimatorConditionMode.IfNot,0,"IsLocal");}
  static void Display(GameObject root,AnywhereMMD[] configs,string folder,string parameter){
   var fx=AnimatorController.CreateAnimatorControllerAtPath(folder+"/Display.controller");fx.AddParameter(parameter,AnimatorControllerParameterType.Int);fx.AddParameter("IsLocal",AnimatorControllerParameterType.Bool);
   var visible=new AnimationClip{name="Audience Visible"};var hidden=new AnimationClip{name="Audience Hidden"};var cameraOn=new AnimationClip{name="Camera Only On"};var cameraOff=new AnimationClip{name="Camera Only Off"};
   foreach(var cfg in configs){string path=AnimationUtility.CalculateTransformPath(cfg.transform,root.transform),screen=AnimationUtility.CalculateTransformPath(cfg.screen.transform,root.transform);Curve(visible,path,typeof(GameObject),"m_IsActive",1,.1f);Curve(hidden,path,typeof(GameObject),"m_IsActive",0,.1f);Curve(cameraOn,screen,typeof(MeshRenderer),"material._CameraOnly",1,.1f);Curve(cameraOff,screen,typeof(MeshRenderer),"material._CameraOnly",0,.1f);}
   foreach(var c in new[]{visible,hidden,cameraOn,cameraOff})Save(c,folder+"/"+c.name+".anim");var audience=fx.layers[0].stateMachine;var show=State(audience,"Visible",visible);var hide=State(audience,"Remote Hidden",hidden);audience.defaultState=show;To(audience,show,parameter,0);To(audience,show,parameter,1);To(audience,show,parameter,-1,true);To(audience,hide,parameter,2,false);To(audience,hide,parameter,3,false);
   fx.AddLayer("Camera View");var camera=fx.layers[1].stateMachine;var off=State(camera,"Normal",cameraOff);var on=State(camera,"Camera Only",cameraOn);camera.defaultState=off;To(camera,off,parameter,0);To(camera,on,parameter,1);To(camera,off,parameter,2);To(camera,on,parameter,3);var layers=fx.layers;foreach(var l in layers)l.defaultWeight=1;fx.layers=layers;EditorUtility.SetDirty(fx);Merge(root,fx);
  }
 }
}
