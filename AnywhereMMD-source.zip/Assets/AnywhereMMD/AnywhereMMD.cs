using UnityEngine;
using VRC.SDKBase;
namespace Pokahina.AnywhereMMD {
 [AddComponentMenu("Pokahina/Anywhere MMD")]
 public sealed class AnywhereMMD : MonoBehaviour, IEditorOnly {
  public bool followAvatarSettings=true;
  public string songFolder="";
  public string captureGroup="";
  public RuntimeAnimatorController danceController;
  public Transform performance;
  public Transform stage;
  public Camera captureCamera;
  public Renderer screen;
  public bool autoFitCamera=true;
  [Tooltip("元MMDワールドのカメラ基準は目線高1.5mです。")]
  [Range(.5f,3f)] public float cameraReferenceHeight=1.5f;
  [Range(.5f,2f)] public float cameraFitMultiplier=1;
  public float cameraHeightOffset=0;
  [Range(2,50)] public float viewingRange=20;
  [Range(128,3840)] public int captureWidth=2560;
  [Tooltip("専用の小さな撮影ステージ。通常のプレイヤー位置から離します。")]
  public Vector3 stageOffset=new Vector3(0,256,0);
  [Range(.005f,.1f)] public float stageScale=.02f;
 }
}
