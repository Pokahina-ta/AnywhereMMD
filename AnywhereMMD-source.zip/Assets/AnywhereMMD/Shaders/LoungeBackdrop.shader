Shader "Pokahina/Dance Lounge Backdrop" {
 Properties { _Color("Velvet",Color)=(.035,.008,.022,1) _Accent("Light",Color)=(.8,.3,.12,1) _Floor("Floor",Float)=0 }
 SubShader {Tags{"Queue"="Geometry" "RenderType"="Opaque"} Cull Off ZWrite On
 Pass { CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 float4 _Color,_Accent;float _Floor;
 struct v2f {float4 pos:SV_POSITION;float3 local:TEXCOORD0;};
 v2f vert(appdata_base v){v2f o;o.pos=UnityObjectToClipPos(v.vertex);o.local=v.vertex.xyz;return o;}
 fixed4 frag(v2f i):SV_Target{
  float3 p=normalize(i.local);float angle=atan2(p.z,p.x);float folds=pow(.5+.5*cos(angle*36),3);
  float3 col=_Color.rgb*(.5+folds*.7);float vertical=smoothstep(-.5,.25,p.y);col*=.55+vertical*.45;
  float slit=pow(saturate(cos(angle*8)),100);float glow=pow(saturate(cos(angle*8)),14)*.04;
  col+=_Accent.rgb*(slit*.2+glow)*smoothstep(-.45,-.1,p.y)*(1-smoothstep(.1,.6,p.y));
  if(_Floor>.5){float cameraHeight=mul(unity_WorldToObject,float4(_WorldSpaceCameraPos,1)).y;clip(cameraHeight-0.0001);float2 uv=i.local.xz;float r=length(uv);float rings=pow(saturate(cos(r*6.2831853)),80);float seams=pow(saturate(cos(atan2(uv.y,uv.x)*12)),100);col=_Color.rgb*.5+_Accent.rgb*(rings*.14+seams*.025)*exp(-r*.16);}
  return float4(col,1);
 }
 ENDCG }
 } Fallback Off
}
