Shader "Pokahina/Dance Lounge Screen" {
 Properties { _CameraOnly("Camera Only",Float)=0 _SceneTex("Film",2D)="black"{} _CaptureFar("Capture far plane",Float)=80 _Range("Range",Float)=20 _Opacity("Opacity",Range(0,1))=1}
 SubShader {Tags{"Queue"="Overlay+100" "RenderType"="Overlay" "IgnoreProjector"="True" "DisableBatching"="True"}Cull Off ZWrite Off ZTest Always
 Pass {CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "UnityCG.cginc"
 sampler2D _SceneTex;float _CaptureFar,_Range,_Opacity,_VRChatMirrorMode,_VRChatCameraMode,_CameraOnly;
 struct appdata {float4 vertex:POSITION;float2 uv:TEXCOORD0;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct v2f {float4 pos:SV_POSITION;float2 uv:TEXCOORD0;float visible:TEXCOORD1;UNITY_VERTEX_OUTPUT_STEREO};
 v2f vert(appdata v){v2f o;UNITY_SETUP_INSTANCE_ID(v);UNITY_INITIALIZE_OUTPUT(v2f,o);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);float3 center=mul(unity_ObjectToWorld,float4(0,0,0,1)).xyz;o.visible=step(distance(_WorldSpaceCameraPos,center),_Range)*step(.001,abs(_ProjectionParams.z-_CaptureFar))*(1-step(.5,_VRChatMirrorMode));o.visible*=lerp(1,step(.5,_VRChatCameraMode),step(.5,_CameraOnly));o.pos=float4(v.vertex.xy*2,0,1);o.pos.y*=_ProjectionParams.x;o.uv=v.uv;return o;}

 // The film is a mono texture. Map a common head-space direction into it,
 // rather than equating the centers of two asymmetric eye projections.
 float2 MMDDisplayFilmUV(float2 uv) {
 #if defined(USING_STEREO_MATRICES)
  float4 eyeRay=mul(unity_CameraInvProjection,float4(uv*2-1,0,1));
  float3 worldRay=mul((float3x3)UNITY_MATRIX_I_V,eyeRay.xyz);
  float3 right=normalize(unity_StereoMatrixV[0][0].xyz+unity_StereoMatrixV[1][0].xyz);
  float3 up=normalize(unity_StereoMatrixV[0][1].xyz+unity_StereoMatrixV[1][1].xyz);
  float3 forward=-normalize(unity_StereoMatrixV[0][2].xyz+unity_StereoMatrixV[1][2].xyz);
  float width0=(1+abs(unity_StereoCameraProjection[0][0][2]))/max(abs(unity_StereoCameraProjection[0][0][0]),.0001);
  float width1=(1+abs(unity_StereoCameraProjection[1][0][2]))/max(abs(unity_StereoCameraProjection[1][0][0]),.0001);
  float width=max(width0,width1);
  float depth=max(dot(worldRay,forward),.0001);
  return float2(dot(worldRay,right),dot(worldRay,up)*(16.0/9.0))/(2*width*depth)+.5;
 #else
  uv.y=(uv.y-.5)*(16.0/9.0)/(_ScreenParams.x/_ScreenParams.y)+.5;
  return uv;
 #endif
 }
 fixed4 frag(v2f i):SV_Target{UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);clip(i.visible-.5);clip(_Opacity-.001);float2 uv=MMDDisplayFilmUV(i.uv);if(any(uv<0)||any(uv>1))return float4(0,0,0,1);return float4(tex2D(_SceneTex,uv).rgb,1);}
 ENDCG }
 }Fallback Off
}
