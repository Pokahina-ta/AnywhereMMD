Shader "Pokahina/Dance Lounge Screen" {
 Properties { _CameraOnly("Camera Only",Float)=0 _SceneTex("Film",2D)="black"{} _CaptureFar("Capture far plane",Float)=80 _Range("Range",Float)=20 _Opacity("Opacity",Range(0,1))=1}
 SubShader {Tags{"Queue"="Overlay+100" "RenderType"="Overlay" "IgnoreProjector"="True" "DisableBatching"="True"}Cull Off ZWrite Off ZTest Always
 Pass {CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "UnityCG.cginc"
 sampler2D _SceneTex;float _CaptureFar,_Range,_Opacity,_VRChatMirrorMode,_VRChatCameraMode,_CameraOnly;
 struct appdata {float4 vertex:POSITION;float2 uv:TEXCOORD0;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct v2f {float4 pos:SV_POSITION;float2 uv:TEXCOORD0;float visible:TEXCOORD1;UNITY_VERTEX_OUTPUT_STEREO};
 v2f vert(appdata v){v2f o;UNITY_SETUP_INSTANCE_ID(v);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);float3 center=mul(unity_ObjectToWorld,float4(0,0,0,1)).xyz;o.visible=step(distance(_WorldSpaceCameraPos,center),_Range)*step(.001,abs(_ProjectionParams.z-_CaptureFar))*(1-step(.5,_VRChatMirrorMode));o.visible*=lerp(1,step(.5,_VRChatCameraMode),step(.5,_CameraOnly));o.pos=float4(v.vertex.xy*2,0,1);o.pos.y*=_ProjectionParams.x;o.uv=v.uv;return o;}
 fixed4 frag(v2f i):SV_Target{UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);clip(i.visible-.5);clip(_Opacity-.001);float aspect=_ScreenParams.x/_ScreenParams.y;
 #if defined(UNITY_SINGLE_PASS_STEREO) && !defined(UNITY_STEREO_INSTANCING_ENABLED) && !defined(UNITY_STEREO_MULTIVIEW_ENABLED)
 aspect*=.5;
 #endif
 float2 uv=i.uv;uv.y=(uv.y-.5)*(16.0/9.0)/aspect+.5;if(uv.y<0||uv.y>1)return float4(0,0,0,1);return float4(tex2D(_SceneTex,uv).rgb,1);}
 ENDCG }
 }Fallback Off
}
